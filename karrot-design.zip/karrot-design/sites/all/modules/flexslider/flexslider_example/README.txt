FlexSlider Example
==================

Contains sample configurations for FlexSlider. You can use these as a starting point for creating your own FlexSlider configurations.

Dependencies
------------

- FlexSlider Views
- FlexSlider Fields
- FlexSlider
- Context